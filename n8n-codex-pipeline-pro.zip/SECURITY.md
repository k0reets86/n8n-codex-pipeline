# Security Policy

- Секреты (`N8N_API_KEY`, `N8N_BASE_URL`, `N8N_TEST_WEBHOOK_URL`) храним только в GitHub Secrets.
- Учётные данные n8n (креды узлов) не коммитим.
- На доступ к n8n выдавайте токены с минимальными правами.
