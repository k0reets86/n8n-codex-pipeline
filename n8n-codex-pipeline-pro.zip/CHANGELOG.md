# Changelog

## 0.1.0
- Базовый каркас CI/CD для n8n
- Валидация JSON‑воркфлоу (Node + jq)
- Смоук‑тест вебхука (Node + bash)
