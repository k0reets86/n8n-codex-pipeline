# Вклад в проект

1. Все изменения через Pull Request.
2. JSON‑воркфлоу кладём в `workflows/`.
3. Перед PR запускаем локально:
   ```bash
   node scripts/validate_workflows.js
   ```
4. В PR обязательно описываем, как тестировать (вебхук, пример payload).
